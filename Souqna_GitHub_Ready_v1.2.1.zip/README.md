# سوقنا - Souqna App

تطبيق Flutter لماركت بليس "سوقنا" متصل بواجهة WordPress REST API.

API Base:

```text
https://sauqna.com/wp-json/sooqna/v1
```

## المزايا الحالية

- تسجيل الدخول وإنشاء الحساب.
- حفظ Bearer Token باستخدام Android Secure Storage.
- عرض المنتجات والتصنيفات.
- سلة المشتريات.
- إنشاء الطلبات.
- لوحة التاجر.
- لوحة المسوق.
- لوحة المندوب.
- تحديث حالات الطلبات من خلال API.
- واجهة عربية RTL.

## هيكل المشروع

```text
pubspec.yaml
lib/
  main.dart
  models/
  services/
  screens/
  theme/
wordpress-plugin/
supabase/
tools/
.github/workflows/build-apk.yml
```

## بناء APK على GitHub

راجع `ANDROID_BUILD_AR.md`.

الـ Workflow يقوم تلقائيًا بإنشاء منصة Android من مشروع Flutter ثم يبني APK إصدار Release ويرفعه كـ Artifact.

## ملاحظة عن Supabase

ملف `supabase/schema.sql` محفوظ كملف سابق/مرجعي للمشروع، لكن التطبيق الحالي يستخدم WordPress API في `lib/services/api_service.dart`، ولا يحتاج مفاتيح Supabase لبناء APK.

## API

التطبيق يعتمد على:

- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/logout`
- `GET /me`
- `GET /categories`
- `GET /products`
- `GET /products/{id}`
- `GET /orders`
- `POST /orders`
- `GET /orders/{id}`
- `GET/POST /merchant/products`
- `GET /merchant/orders`
- `GET /marketer/dashboard`
- `GET /courier/orders`
- `POST /courier/orders/{id}/claim`
- `POST /courier/orders/{id}/status`
