import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';
import 'order_details_screen.dart';

class CourierDashboard extends StatefulWidget {
  const CourierDashboard({super.key});
  @override State<CourierDashboard> createState() => _CourierDashboardState();
}

class _CourierDashboardState extends State<CourierDashboard> {
  late Future<List<Map<String, dynamic>>> _ordersFuture;
  @override void initState() { super.initState(); _ordersFuture = ApiService.instance.courierOrders(); }
  void _refresh() => setState(() => _ordersFuture = ApiService.instance.courierOrders());

  String _statusLabel(String status) {
    switch (status) {
      case 'pending': return 'بانتظار الاستلام';
      case 'preparing': return 'قيد التجهيز';
      case 'out_for_delivery': return 'في الطريق';
      case 'delivered': return 'تم التوصيل';
      case 'cancelled': return 'ملغي';
      default: return status;
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('لوحة المندوب')),
    body: FutureBuilder<List<Map<String,dynamic>>>(
      future: _ordersFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
        if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24),
          child: Text('تعذر تحميل الطلبات\n${snapshot.error}', textAlign: TextAlign.center)));
        final orders = snapshot.data ?? [];
        if (orders.isEmpty) return const Center(child: Text('لا توجد طلبات متاحة حاليًا',
          style: TextStyle(color: AppColors.textSecondary)));
        return RefreshIndicator(
          onRefresh: () async => _refresh(),
          child: ListView(padding: const EdgeInsets.all(16), children: orders.map((o) => InkWell(
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => OrderDetailsScreen(order: o)));
              _refresh();
            },
            child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.white, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.bgLight, width: 2)),
              child: Row(children: [
                const Icon(Icons.local_shipping_outlined, color: AppColors.primary),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('طلب #${o['id']}', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
                  Text(o['shipping_address']?['address_1']?.toString() ?? o['billing']?['address_1']?.toString() ?? '',
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                ])),
                Text(_statusLabel(o['status']?.toString() ?? ''), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.gold)),
              ]),
            ),
          )).toList()),
        );
      },
    ),
  );
}
