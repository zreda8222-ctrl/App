import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/api_service.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _nameController = TextEditingController();
  final _categoryController = TextEditingController();
  final _priceController = TextEditingController();
  final _maxPriceController = TextEditingController();
  final _stockController = TextEditingController();
  String? _error;
  bool _loading = false;

  Future<void> _submit() async {
    final name = _nameController.text.trim();
    final base = double.tryParse(_priceController.text.trim());
    final max = double.tryParse(_maxPriceController.text.trim());
    final stock = int.tryParse(_stockController.text.trim());
    if (name.isEmpty || base == null || max == null || stock == null) {
      setState(() => _error = 'من فضلك أدخل بيانات صحيحة لكل الحقول المطلوبة');
      return;
    }
    if (max < base || stock < 0) {
      setState(() => _error = 'تأكد من السعر الأقصى والمخزون');
      return;
    }

    setState(() { _loading = true; _error = null; });
    try {
      await ApiService.instance.merchantCreateProduct(
        name: name, price: base, maxSuggestedPrice: max, stock: stock,
        category: _categoryController.text,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت إضافة المنتج بنجاح')));
      Navigator.pop(context);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة منتج جديد')),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _field('اسم المنتج', _nameController),
        _field('التصنيف', _categoryController),
        _field('السعر الأساسي (ر.س)', _priceController, number: true),
        _field('أقصى سعر بيع للمسوق (ر.س)', _maxPriceController, number: true),
        _field('الكمية بالمخزون', _stockController, number: true),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 12),
          child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13))),
        const SizedBox(height: 24),
        ElevatedButton(onPressed: _loading ? null : _submit,
          child: _loading ? const SizedBox(width: 20, height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('حفظ المنتج')),
      ]),
    ),
  );

  Widget _field(String label, TextEditingController controller, {bool number = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
      const SizedBox(height: 6),
      TextField(controller: controller, keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: const InputDecoration(border: OutlineInputBorder())),
    ]),
  );
}
