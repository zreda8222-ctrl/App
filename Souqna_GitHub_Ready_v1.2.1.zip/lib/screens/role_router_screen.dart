import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/auth_service.dart';
import 'customer/home_screen.dart';
import 'merchant/merchant_dashboard.dart';
import 'marketer/marketer_dashboard.dart';
import 'courier/courier_dashboard.dart';
import 'auth/login_screen.dart';

/// شاشة وسيطة: تقرأ دور المستخدم المسجل دخوله وتوديه للوحته الصحيحة
class RoleRouterScreen extends StatelessWidget {
  const RoleRouterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: AuthService.getCurrentUserRole(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator(color: AppColors.primary)),
          );
        }

        final role = snapshot.data;
        if (role == null) {
          return const LoginScreen();
        }

        switch (role) {
          case 'merchant':
            return const MerchantDashboard();
          case 'marketer':
            return const MarketerDashboard();
          case 'courier':
            return const CourierDashboard();
          case 'customer':
          default:
            return const HomeScreen();
        }
      },
    );
  }
}
