import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  static const String baseUrl = 'https://sauqna.com/wp-json/sooqna/v1';
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static const String _tokenKey = 'sooqna_api_token';

  String? _token;

  Future<void> init() async {
    _token = await _storage.read(key: _tokenKey);
  }

  bool get isAuthenticated => _token != null && _token!.isNotEmpty;

  Map<String, String> _headers({bool jsonBody = false}) => {
        'Accept': 'application/json',
        if (jsonBody) 'Content-Type': 'application/json',
        if (isAuthenticated) 'Authorization': 'Bearer $_token',
      };

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    Map<String, String>? query,
    bool auth = false,
  }) async {
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: query);
    late http.Response response;

    try {
      switch (method) {
        case 'GET':
          response = await http.get(uri, headers: _headers());
          break;
        case 'POST':
          response = await http.post(uri, headers: _headers(jsonBody: true), body: jsonEncode(body ?? {}));
          break;
        case 'PUT':
          response = await http.put(uri, headers: _headers(jsonBody: true), body: jsonEncode(body ?? {}));
          break;
        default:
          throw ApiException('طريقة الطلب غير مدعومة');
      }
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('تعذر الاتصال بسوقنا. تحقق من الإنترنت.');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(utf8.decode(response.bodyBytes));
    } catch (_) {
      throw ApiException('استجابة غير صالحة من الخادم', statusCode: response.statusCode);
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['message'] ?? decoded['code'] ?? 'حدث خطأ في الخادم').toString()
          : 'حدث خطأ في الخادم';
      throw ApiException(message, statusCode: response.statusCode);
    }

    if (auth && !isAuthenticated) {
      throw ApiException('يلزم تسجيل الدخول');
    }

    return Map<String, dynamic>.from(decoded as Map);
  }

  Future<Map<String, dynamic>> login(String login, String password) async {
    final data = await _request('POST', '/auth/login', body: {
      'login': login,
      'password': password,
    });
    await _saveToken(data['token'] as String);
    return data;
  }

  Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String fullName,
    String? phone,
    String role = 'customer',
  }) async {
    // The public WordPress API creates customer accounts only.
    // Merchant/marketer/courier roles should be provisioned by the marketplace.
    final parts = fullName.trim().split(RegExp(r'\s+'));
    final firstName = parts.isEmpty ? fullName.trim() : parts.first;
    final lastName = parts.length > 1 ? parts.sublist(1).join(' ') : '';

    final data = await _request('POST', '/auth/register', body: {
      'email': email,
      'password': password,
      'first_name': firstName,
      'last_name': lastName,
      'username': email.split('@').first,
      'phone': phone,
      'role': role,
    });
    await _saveToken(data['token'] as String);
    return data;
  }

  Future<void> logout() async {
    if (isAuthenticated) {
      try {
        await _request('POST', '/auth/logout', auth: true);
      } catch (_) {}
    }
    _token = null;
    await _storage.delete(key: _tokenKey);
  }

  Future<Map<String, dynamic>> me() => _request('GET', '/me', auth: true);

  Future<List<Map<String, dynamic>>> products({
    int page = 1,
    int perPage = 50,
    String search = '',
    int? category,
  }) async {
    final data = await _request('GET', '/products', query: {
      'page': '$page',
      'per_page': '$perPage',
      if (search.trim().isNotEmpty) 'search': search.trim(),
      if (category != null) 'category': '$category',
    });
    return (data['products'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<Map<String, dynamic>> product(int id) =>
      _request('GET', '/products/$id');

  Future<List<Map<String, dynamic>>> categories() async {
    final data = await _request('GET', '/categories');
    return (data['categories'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<Map<String, dynamic>> createOrder({
    required List<Map<String, dynamic>> items,
    required String address,
    String? phone,
    String? fullName,
    String paymentMethod = 'cod',
    String? marketerId,
    String? affiliateId,
  }) async {
    final billing = {
      'first_name': fullName ?? '',
      'phone': phone ?? '',
      'address_1': address,
      'country': 'SA',
    };

    return _request('POST', '/orders', auth: true, body: {
      'items': items,
      'billing': billing,
      'shipping': billing,
      'payment_method': paymentMethod,
      'payment_method_title': 'الدفع عند الاستلام',
      if (marketerId != null) 'marketer_id': marketerId,
      if (affiliateId != null) 'affiliate_id': affiliateId,
    });
  }

  Future<List<Map<String, dynamic>>> orders() async {
    final data = await _request('GET', '/orders', auth: true);
    return (data['orders'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<Map<String, dynamic>> order(int id) =>
      _request('GET', '/orders/$id', auth: true);


  Future<List<Map<String, dynamic>>> merchantProducts() async {
    final data = await _request('GET', '/merchant/products', auth: true);
    return (data['products'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> merchantCreateProduct({
    required String name,
    required double price,
    required double maxSuggestedPrice,
    required int stock,
    String? category,
  }) => _request('POST', '/merchant/products', auth: true, body: {
        'name': name,
        'price': price,
        'max_suggested_price': maxSuggestedPrice,
        'stock': stock,
        if (category != null && category.trim().isNotEmpty) 'category': category.trim(),
      });

  Future<List<Map<String, dynamic>>> merchantOrders() async {
    final data = await _request('GET', '/merchant/orders', auth: true);
    return (data['orders'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> marketerDashboard() =>
      _request('GET', '/marketer/dashboard', auth: true);

  Future<List<Map<String, dynamic>>> courierOrders() async {
    final data = await _request('GET', '/courier/orders', auth: true);
    return (data['orders'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> courierClaim(int orderId) =>
      _request('POST', '/courier/orders/$orderId/claim', auth: true);

  Future<Map<String, dynamic>> courierStatus(int orderId, String status) =>
      _request('POST', '/courier/orders/$orderId/status',
          auth: true, body: {'status': status});

  Future<void> _saveToken(String token) async {
    _token = token;
    await _storage.write(key: _tokenKey, value: token);
  }
}
