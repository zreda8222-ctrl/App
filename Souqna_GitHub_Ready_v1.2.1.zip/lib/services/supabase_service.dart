// Supabase has been replaced by the native WordPress API.
// Kept as a placeholder so older project paths do not break.
