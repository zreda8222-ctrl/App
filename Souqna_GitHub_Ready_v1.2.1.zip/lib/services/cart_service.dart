import 'package:flutter/foundation.dart';
import '../models/product.dart';

/// خدمة بسيطة لإدارة السلة، singleton من غير الحاجة لمكتبات خارجية
class CartService {
  CartService._internal();
  static final CartService instance = CartService._internal();

  final ValueNotifier<List<OrderItem>> items = ValueNotifier([]);

  void add(Product product, {int quantity = 1, double? sellPrice}) {
    final price = sellPrice ?? product.basePrice;
    items.value = [
      ...items.value,
      OrderItem(product: product, quantity: quantity, sellPrice: price),
    ];
  }

  void removeAt(int index) {
    final updated = [...items.value]..removeAt(index);
    items.value = updated;
  }

  void clear() {
    items.value = [];
  }

  double get total =>
      items.value.fold(0, (sum, item) => sum + item.total);
}
