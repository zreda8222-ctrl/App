#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null 2>&1 || { echo 'Flutter SDK غير مثبت. ثبّت Flutter ثم أعد تشغيل السكربت.'; exit 1; }
flutter create . --platforms=android --project-name souqna_app --org com.alkyanmedia
flutter pub get
# Set Arabic app label where possible
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
if p.exists():
    s=p.read_text()
    s=s.replace('android:label="souqna_app"','android:label="سوقنا"')
    p.write_text(s)
PY
echo 'Android project prepared.'
