<?php
/**
 * Plugin Name: Sooqna Mobile API
 * Description: Secure mobile API bridge for سوقنا / WooCommerce. Provides token authentication, products, categories, customers and order endpoints for the native app.
 * Version: 1.1.0
 * Author: الكيان ميديا - رضا أبوهاشم
 * Author URI: https://alkyanmedia.com/
 * Requires at least: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

final class Sooqna_Mobile_API {
    const NS = 'sooqna/v1';
    const TOKEN_META = '_sooqna_api_tokens';
    const TOKEN_TTL = 2592000; // 30 days

    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'routes']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'admin_init']);
        add_filter('rest_pre_serve_request', [__CLASS__, 'cors'], 10, 4);
    }

    public static function cors($served, $result, $request, $server) {
        $origin = get_http_origin();
        if ($origin) {
            header('Access-Control-Allow-Origin: ' . esc_url_raw($origin));
            header('Vary: Origin');
            header('Access-Control-Allow-Credentials: false');
        }
        header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With');
        header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
        return $served;
    }

    public static function routes() {
        register_rest_route(self::NS, '/health', [
            'methods'=>'GET','callback'=>[__CLASS__,'health'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/auth/register', [
            'methods'=>'POST','callback'=>[__CLASS__,'register'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/auth/login', [
            'methods'=>'POST','callback'=>[__CLASS__,'login'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/auth/logout', [
            'methods'=>'POST','callback'=>[__CLASS__,'logout'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/me', [
            'methods'=>'GET','callback'=>[__CLASS__,'me'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/categories', [
            'methods'=>'GET','callback'=>[__CLASS__,'categories'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/products', [
            'methods'=>'GET','callback'=>[__CLASS__,'products'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/products/(?P<id>\d+)', [
            'methods'=>'GET','callback'=>[__CLASS__,'product'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(self::NS, '/orders', [
            'methods'=>'GET','callback'=>[__CLASS__,'orders'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/orders', [
            'methods'=>'POST','callback'=>[__CLASS__,'create_order'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/orders/(?P<id>\d+)', [
            'methods'=>'GET','callback'=>[__CLASS__,'order'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/merchant/products', [
            'methods'=>'GET','callback'=>[__CLASS__,'merchant_products'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/merchant/products', [
            'methods'=>'POST','callback'=>[__CLASS__,'merchant_create_product'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/merchant/orders', [
            'methods'=>'GET','callback'=>[__CLASS__,'merchant_orders'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/marketer/dashboard', [
            'methods'=>'GET','callback'=>[__CLASS__,'marketer_dashboard'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/courier/orders', [
            'methods'=>'GET','callback'=>[__CLASS__,'courier_orders'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/courier/orders/(?P<id>\d+)/claim', [
            'methods'=>'POST','callback'=>[__CLASS__,'courier_claim'],'permission_callback'=>[__CLASS__,'auth']
        ]);
        register_rest_route(self::NS, '/courier/orders/(?P<id>\d+)/status', [
            'methods'=>'POST','callback'=>[__CLASS__,'courier_status'],'permission_callback'=>[__CLASS__,'auth']
        ]);
    }

    private static function ok($data, $status=200) {
        return new WP_REST_Response($data, $status);
    }
    private static function err($message, $status=400, $code='sooqna_error') {
        return new WP_Error($code, $message, ['status'=>$status]);
    }

    public static function health() {
        $wc = class_exists('WooCommerce');
        return self::ok([
            'success'=>true,
            'service'=>'Sooqna Mobile API',
            'version'=>'1.0.0',
            'wordpress'=>get_bloginfo('version'),
            'woocommerce'=>$wc,
            'timestamp'=>current_time('c')
        ]);
    }

    private static function payload(WP_REST_Request $r) {
        $json = $r->get_json_params();
        return is_array($json) ? $json : [];
    }

    private static function token_secret() {
        return wp_salt('auth');
    }

    private static function b64($s) {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }
    private static function ub64($s) {
        return base64_decode(strtr($s, '-_', '+/'));
    }

    private static function make_token($user_id) {
        $header = self::b64(wp_json_encode(['alg'=>'HS256','typ'=>'JWT']));
        $now = time(); $exp = $now + self::TOKEN_TTL;
        $payload = self::b64(wp_json_encode(['uid'=>(int)$user_id,'iat'=>$now,'exp'=>$exp,'jti'=>wp_generate_uuid4()]));
        $sig = self::b64(hash_hmac('sha256', $header.'.'.$payload, self::token_secret(), true));
        $token = $header.'.'.$payload.'.'.$sig;
        $hash = hash('sha256',$token);
        $tokens = get_user_meta($user_id, self::TOKEN_META, true);
        if (!is_array($tokens)) $tokens=[];
        $tokens[$hash]=$exp;
        foreach ($tokens as $h=>$e) if ((int)$e < $now) unset($tokens[$h]);
        while (count($tokens)>5) array_shift($tokens);
        update_user_meta($user_id,self::TOKEN_META,$tokens);
        return [$token,$exp];
    }

    private static function bearer() {
        $h = isset($_SERVER['HTTP_AUTHORIZATION']) ? trim(wp_unslash($_SERVER['HTTP_AUTHORIZATION'])) : '';
        if (!$h && function_exists('getallheaders')) {
            $headers=getallheaders();
            $h=$headers['Authorization'] ?? $headers['authorization'] ?? '';
        }
        if (stripos($h,'Bearer ')!==0) return '';
        return trim(substr($h,7));
    }

    private static function current_user_id() {
        $token=self::bearer();
        if (!$token) return 0;
        $parts=explode('.',$token);
        if (count($parts)!==3) return 0;
        [$head,$pay,$sig]=$parts;
        $expected=self::b64(hash_hmac('sha256',$head.'.'.$pay,self::token_secret(),true));
        if (!hash_equals($expected,$sig)) return 0;
        $data=json_decode(self::ub64($pay),true);
        if (!is_array($data) || empty($data['uid']) || empty($data['exp']) || (int)$data['exp']<time()) return 0;
        $tokens=get_user_meta((int)$data['uid'],self::TOKEN_META,true);
        $hash=hash('sha256',$token);
        if (!is_array($tokens) || !isset($tokens[$hash]) || (int)$tokens[$hash]<time()) return 0;
        return (int)$data['uid'];
    }

    public static function auth() {
        $uid=self::current_user_id();
        if (!$uid) return self::err('Authentication required',401,'rest_not_logged_in');
        return true;
    }

    public static function register(WP_REST_Request $r) {
        if (!class_exists('WooCommerce')) return self::err('WooCommerce is required',503);
        $p=self::payload($r);
        $email=sanitize_email($p['email'] ?? '');
        $password=(string)($p['password'] ?? '');
        $first=sanitize_text_field($p['first_name'] ?? '');
        $last=sanitize_text_field($p['last_name'] ?? '');
        if (!is_email($email)) return self::err('Valid email is required');
        if (strlen($password)<8) return self::err('Password must be at least 8 characters');
        if (email_exists($email)) return self::err('Email already exists',409,'email_exists');
        $username=sanitize_user($p['username'] ?? '',true);
        if (!$username) $username=current(explode('@',$email));
        if (username_exists($username)) $username .= '_' . wp_rand(100,999);
        $uid=wc_create_new_customer($email,$username,$password,[
            'first_name'=>$first,'last_name'=>$last
        ]);
        if (is_wp_error($uid)) return $uid;
        if ($first) update_user_meta($uid,'first_name',$first);
        if ($last) update_user_meta($uid,'last_name',$last);
        [$token,$exp]=self::make_token($uid);
        return self::ok(['success'=>true,'token'=>$token,'expires_at'=>gmdate('c',$exp),'user'=>self::user_data($uid)],201);
    }

    public static function login(WP_REST_Request $r) {
        $p=self::payload($r);
        $login=sanitize_text_field($p['login'] ?? $p['email'] ?? '');
        $password=(string)($p['password'] ?? '');
        if (!$login || !$password) return self::err('Login and password are required');
        $user=get_user_by('email',$login);
        if (!$user) $user=get_user_by('login',$login);
        if (!$user || !wp_check_password($password,$user->user_pass,$user->ID)) {
            return self::err('Invalid login credentials',401,'invalid_credentials');
        }
        [$token,$exp]=self::make_token($user->ID);
        return self::ok(['success'=>true,'token'=>$token,'expires_at'=>gmdate('c',$exp),'user'=>self::user_data($user->ID)]);
    }

    public static function logout() {
        $uid=self::current_user_id(); $token=self::bearer();
        $tokens=get_user_meta($uid,self::TOKEN_META,true);
        if (is_array($tokens)) { unset($tokens[hash('sha256',$token)]); update_user_meta($uid,self::TOKEN_META,$tokens); }
        return self::ok(['success'=>true]);
    }

    private static function user_data($uid) {
        $u=get_userdata($uid);
        return [
            'id'=>$uid,'username'=>$u->user_login,'email'=>$u->user_email,
            'first_name'=>$u->first_name,'last_name'=>$u->last_name,
            'display_name'=>$u->display_name,'roles'=>$u->roles
        ];
    }
    public static function me() { return self::ok(['success'=>true,'user'=>self::user_data(self::current_user_id())]); }

    public static function categories(WP_REST_Request $r) {
        $terms=get_terms(['taxonomy'=>'product_cat','hide_empty'=>true]);
        if (is_wp_error($terms)) return $terms;
        $out=[];
        foreach ($terms as $t) $out[]=['id'=>(int)$t->term_id,'name'=>$t->name,'slug'=>$t->slug,'count'=>(int)$t->count,'image'=>self::category_image($t->term_id)];
        return self::ok(['success'=>true,'categories'=>$out]);
    }
    private static function category_image($term_id) {
        $thumb=get_term_meta($term_id,'thumbnail_id',true);
        return $thumb ? wp_get_attachment_image_url($thumb,'medium') : null;
    }

    private static function product_data($p) {
        $img=wp_get_attachment_image_url($p->get_image_id(),'woocommerce_thumbnail');
        $gallery=[];
        foreach ($p->get_gallery_image_ids() as $id) { $u=wp_get_attachment_image_url($id,'large'); if($u)$gallery[]=$u; }
        $cats=[];
        foreach ($p->get_category_ids() as $cid) { $t=get_term($cid,'product_cat'); if($t&&!is_wp_error($t))$cats[]=['id'=>(int)$t->term_id,'name'=>$t->name,'slug'=>$t->slug]; }
        $vendor_id=(int)get_post_field('post_author',$p->get_id());
        $regular=(float)$p->get_regular_price();
        $sale=$p->get_sale_price()!==''?(float)$p->get_sale_price():null;
        $max_meta=get_post_meta($p->get_id(),'_sooqna_max_suggested_price',true);
        $max_price=$max_meta!==''?(float)$max_meta:$regular;
        return [
            'id'=>$p->get_id(),'name'=>$p->get_name(),'slug'=>$p->get_slug(),
            'description'=>wp_strip_all_tags($p->get_description()),
            'short_description'=>wp_strip_all_tags($p->get_short_description()),
            'price'=>(float)$p->get_price(),'regular_price'=>$regular,
            'sale_price'=>$sale,
            'base_price'=>$regular,'max_suggested_price'=>$max_price,
            'currency'=>get_woocommerce_currency(),'stock_status'=>$p->get_stock_status(),
            'stock_quantity'=>$p->get_stock_quantity(),'type'=>$p->get_type(),
            'image'=>$img,'gallery'=>$gallery,'categories'=>$cats,
            'vendor_id'=>$vendor_id
        ];
    }

    public static function products(WP_REST_Request $r) {
        if (!class_exists('WooCommerce')) return self::err('WooCommerce is required',503);
        $args=[
            'status'=>'publish',
            'limit'=>min(100,max(1,(int)($r['per_page']??20))),
            'page'=>max(1,(int)($r['page']??1)),
            'search'=>sanitize_text_field($r['search']??''),
            'category'=>$r['category']?(string)(int)$r['category']:'',
        ];
        $products=wc_get_products($args); $out=[];
        foreach($products as $p)$out[]=self::product_data($p);
        return self::ok(['success'=>true,'products'=>$out,'page'=>(int)$args['page'],'per_page'=>(int)$args['limit']]);
    }
    public static function product(WP_REST_Request $r) {
        $p=wc_get_product((int)$r['id']);
        if(!$p || $p->get_status()!=='publish') return self::err('Product not found',404,'not_found');
        return self::ok(['success'=>true,'product'=>self::product_data($p)]);
    }

    public static function orders() {
        $uid=self::current_user_id();
        $orders=wc_get_orders(['customer_id'=>$uid,'limit'=>50,'orderby'=>'date','order'=>'DESC']);
        $out=[];
        foreach($orders as $o)$out[]=self::order_data($o);
        return self::ok(['success'=>true,'orders'=>$out]);
    }
    public static function order(WP_REST_Request $r) {
        $o=wc_get_order((int)$r['id']);
        if(!$o || (int)$o->get_customer_id()!==self::current_user_id()) return self::err('Order not found',404,'not_found');
        return self::ok(['success'=>true,'order'=>self::order_data($o)]);
    }
    private static function order_data($o) {
        $items=[];
        foreach($o->get_items() as $item){
            $p=$item->get_product();
            $items[]=['product_id'=>$p?(int)$p->get_id():0,'name'=>$item->get_name(),'quantity'=>(int)$item->get_quantity(),'total'=>(float)$item->get_total()];
        }
        $app_status=get_post_meta($o->get_id(),'_sooqna_status',true);
        if(!$app_status) {
            $app_status = $o->is_completed() ? 'delivered' : ($o->has_status('processing') ? 'preparing' : 'pending');
        }
        return ['id'=>$o->get_id(),'status'=>$app_status,'wc_status'=>$o->get_status(),'currency'=>$o->get_currency(),'total'=>(float)$o->get_total(),'subtotal'=>(float)$o->get_subtotal(),'shipping'=>(float)$o->get_shipping_total(),'payment_method'=>$o->get_payment_method(),'created_at'=>$o->get_date_created()?$o->get_date_created()->date('c'):null,'items'=>$items,'billing'=>$o->get_address('billing'),'shipping_address'=>$o->get_address('shipping'),'courier_id'=>(int)get_post_meta($o->get_id(),'_sooqna_courier_id',true),'marketer_id'=>(int)get_post_meta($o->get_id(),'_sooqna_marketer_id',true)];
    }

    public static function create_order(WP_REST_Request $r) {
        if(!class_exists('WooCommerce')) return self::err('WooCommerce is required',503);
        $uid=self::current_user_id(); $p=self::payload($r);
        $items=$p['items']??[];
        if(!is_array($items)||!$items)return self::err('Order items are required');
        $order=wc_create_order(['customer_id'=>$uid]);
        if(is_wp_error($order))return $order;
        foreach($items as $line){
            $pid=absint($line['product_id']??0); $qty=max(1,absint($line['quantity']??1));
            $product=wc_get_product($pid);
            if(!$product || $product->get_status()!=='publish'){ $order->delete(true); return self::err('Invalid product: '.$pid,400,'invalid_product'); }
            if(!$product->is_purchasable()){ $order->delete(true); return self::err('Product is not purchasable: '.$pid,400,'not_purchasable'); }
            $unit=isset($line['price']) ? max((float)$line['price'], (float)$product->get_price()) : (float)$product->get_price();
            $item_id=$order->add_product($product,$qty,[
                'subtotal'=>$unit*$qty,
                'total'=>$unit*$qty,
            ]);
            if($item_id) {
                $item=$order->get_item($item_id);
                if($item) $item->update_meta_data('_sooqna_sell_price',$unit);
            }
        }
        $billing=is_array($p['billing']??null)?$p['billing']:[];
        $shipping=is_array($p['shipping']??null)?$p['shipping']:$billing;
        $order->set_address($billing,'billing'); $order->set_address($shipping,'shipping');
        $pm=sanitize_text_field($p['payment_method']??'cod');
        if(!$pm) $pm='cod';
        $order->set_payment_method($pm);
        $order->set_payment_method_title(sanitize_text_field($p['payment_method_title']??$pm));
        $order->update_meta_data('_sooqna_status','pending');
        if(isset($p['customer_note'])) $order->set_customer_note(sanitize_textarea_field($p['customer_note']));
        // Preserve marketplace attribution when supplied.
        if(isset($p['marketer_id'])) $order->update_meta_data('_sooqna_marketer_id',absint($p['marketer_id']));
        if(isset($p['affiliate_id'])) $order->update_meta_data('_sooqna_affiliate_id',sanitize_text_field($p['affiliate_id']));
        $order->calculate_totals();
        $order->save();
        return self::ok(['success'=>true,'order'=>self::order_data($order)],201);
    }


    private static function can_manage_products($uid) {
        $u=get_userdata($uid);
        if(!$u) return false;
        if(user_can($uid,'manage_woocommerce') || user_can($uid,'edit_products')) return true;
        if(function_exists('dokan_is_user_seller') && dokan_is_user_seller($uid)) return true;
        return false;
    }

    public static function merchant_products() {
        $uid=self::current_user_id();
        if(!self::can_manage_products($uid)) return self::err('Merchant access required',403,'forbidden');
        $products=wc_get_products(['status'=>['publish','draft'],'limit'=>100,'author'=>$uid,'orderby'=>'date','order'=>'DESC']);
        $out=[]; foreach($products as $p) $out[]=self::product_data($p);
        return self::ok(['success'=>true,'products'=>$out]);
    }

    public static function merchant_create_product(WP_REST_Request $r) {
        $uid=self::current_user_id();
        if(!self::can_manage_products($uid)) return self::err('Merchant access required',403,'forbidden');
        $p=self::payload($r);
        $name=sanitize_text_field($p['name']??'');
        $price=(float)($p['price']??$p['base_price']??0);
        $max=(float)($p['max_suggested_price']??$price);
        $stock=max(0,(int)($p['stock']??0));
        if(!$name || $price<0 || $max<$price) return self::err('Invalid product data');
        $pid=wp_insert_post(['post_type'=>'product','post_status'=>'publish','post_title'=>$name,'post_author'=>$uid]);
        if(is_wp_error($pid)) return $pid;
        $product=wc_get_product($pid);
        $product->set_regular_price((string)$price);
        $product->set_price((string)$price);
        $product->set_manage_stock(true);
        $product->set_stock_quantity($stock);
        $product->set_stock_status($stock>0?'instock':'outofstock');
        $product->save();
        update_post_meta($pid,'_sooqna_max_suggested_price',$max);
        if(!empty($p['category'])) {
            $term=term_exists(sanitize_text_field($p['category']),'product_cat');
            if(!$term) $term=wp_insert_term(sanitize_text_field($p['category']),'product_cat');
            if(!is_wp_error($term) && $term) wp_set_object_terms($pid,(int)($term['term_id']??$term),'product_cat');
        }
        return self::ok(['success'=>true,'product'=>self::product_data(wc_get_product($pid))],201);
    }

    public static function merchant_orders() {
        $uid=self::current_user_id();
        if(!self::can_manage_products($uid)) return self::err('Merchant access required',403,'forbidden');
        $orders=wc_get_orders(['limit'=>100,'orderby'=>'date','order'=>'DESC']);
        $out=[];
        foreach($orders as $o) {
            $belongs=false;
            foreach($o->get_items() as $item) {
                $pid=$item->get_product_id();
                if($pid && (int)get_post_field('post_author',$pid)===$uid) { $belongs=true; break; }
            }
            if($belongs) $out[]=self::order_data($o);
        }
        return self::ok(['success'=>true,'orders'=>$out]);
    }

    public static function marketer_dashboard() {
        $uid=self::current_user_id();
        $products=wc_get_products(['status'=>'publish','limit'=>100,'orderby'=>'date','order'=>'DESC']);
        $total=0; $orders=[];
        foreach(wc_get_orders(['limit'=>100,'orderby'=>'date','order'=>'DESC']) as $o) {
            $mid=(int)get_post_meta($o->get_id(),'_sooqna_marketer_id',true);
            if($mid!==$uid) continue;
            $commission=0;
            foreach($o->get_items() as $item) {
                $product=$item->get_product(); if(!$product) continue;
                $qty=(int)$item->get_quantity();
                $sell=(float)$item->get_meta('_sooqna_sell_price',true);
                if(!$sell) $sell=(float)$item->get_total()/max(1,$qty);
                $base=(float)$product->get_price();
                $commission += max(0,$sell-$base)*$qty;
            }
            if(get_post_meta($o->get_id(),'_sooqna_status',true)==='delivered') $total += $commission;
            $orders[]=self::order_data($o);
        }
        $out=[]; foreach($products as $p) $out[]=self::product_data($p);
        return self::ok(['success'=>true,'products'=>$out,'total_commission'=>(float)$total,'orders'=>$orders]);
    }

    public static function courier_orders() {
        $uid=self::current_user_id();
        $u=get_userdata($uid);
        if(!$u || !in_array('courier',(array)$u->roles,true)) return self::err('Courier access required',403,'forbidden');
        $orders=wc_get_orders(['limit'=>100,'orderby'=>'date','order'=>'DESC']);
        $out=[];
        foreach($orders as $o) {
            $cid=(int)get_post_meta($o->get_id(),'_sooqna_courier_id',true);
            $status=get_post_meta($o->get_id(),'_sooqna_status',true);
            if(!$status) $status='pending';
            if($cid===$uid || (!$cid && in_array($status,['pending','preparing'],true))) $out[]=self::order_data($o);
        }
        return self::ok(['success'=>true,'orders'=>$out]);
    }

    public static function courier_claim(WP_REST_Request $r) {
        $uid=self::current_user_id(); $u=get_userdata($uid);
        if(!$u || !in_array('courier',(array)$u->roles,true)) return self::err('Courier access required',403,'forbidden');
        $o=wc_get_order((int)$r['id']);
        if(!$o) return self::err('Order not found',404,'not_found');
        $cid=(int)get_post_meta($o->get_id(),'_sooqna_courier_id',true);
        if($cid && $cid!==$uid) return self::err('Order already claimed',409,'already_claimed');
        update_post_meta($o->get_id(),'_sooqna_courier_id',$uid);
        update_post_meta($o->get_id(),'_sooqna_status','preparing');
        return self::ok(['success'=>true,'order'=>self::order_data($o)]);
    }

    public static function courier_status(WP_REST_Request $r) {
        $uid=self::current_user_id(); $u=get_userdata($uid);
        if(!$u || !in_array('courier',(array)$u->roles,true)) return self::err('Courier access required',403,'forbidden');
        $o=wc_get_order((int)$r['id']);
        if(!$o) return self::err('Order not found',404,'not_found');
        if((int)get_post_meta($o->get_id(),'_sooqna_courier_id',true)!==$uid) return self::err('Order is not assigned to you',403,'forbidden');
        $status=sanitize_key(self::payload($r)['status']??'');
        if(!in_array($status,['preparing','out_for_delivery','delivered','cancelled'],true)) return self::err('Invalid status');
        update_post_meta($o->get_id(),'_sooqna_status',$status);
        if($status==='delivered') $o->set_status('completed');
        elseif($status==='cancelled') $o->set_status('cancelled');
        elseif($status==='preparing' || $status==='out_for_delivery') $o->set_status('processing');
        $o->save();
        return self::ok(['success'=>true,'order'=>self::order_data($o)]);
    }

    public static function admin_menu() {
        add_options_page('Sooqna Mobile API','Sooqna Mobile API','manage_options','sooqna-mobile-api',[__CLASS__,'settings_page']);
    }
    public static function admin_init() {
        register_setting('sooqna_mobile_api','sooqna_api_note',['sanitize_callback'=>'sanitize_text_field']);
    }
    public static function settings_page() {
        if(!current_user_can('manage_options'))return;
        $base=esc_url(rest_url(self::NS.'/'));
        echo '<div class="wrap" dir="rtl"><h1>سوقنا Mobile API</h1>';
        echo '<p>API Base:</p><code style="font-size:16px">'.$base.'</code>';
        echo '<h2>Health Check</h2><p><code>'.esc_html(rest_url(self::NS.'/health')).'</code></p>';
        echo '<h2>Endpoints</h2><ul style="line-height:1.9">';
        foreach(['POST auth/register','POST auth/login','POST auth/logout','GET me','GET categories','GET products','GET products/{id}','GET orders','POST orders','GET orders/{id}','GET/POST merchant/products','GET merchant/orders','GET marketer/dashboard','GET courier/orders','POST courier/orders/{id}/claim','POST courier/orders/{id}/status'] as $e) echo '<li><code>'.esc_html($e).'</code></li>';
        echo '</ul><p><strong>مهم:</strong> لا تستخدم مفاتيح WooCommerce REST API داخل تطبيق العميل. هذا الجسر يستخدم Token للمستخدم.</p></div>';
    }
}
Sooqna_Mobile_API::init();
