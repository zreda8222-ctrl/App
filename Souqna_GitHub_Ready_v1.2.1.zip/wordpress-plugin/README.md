# Sooqna Mobile API 1.1.0

ارفع مجلد `sooqna-mobile-api` كإضافة WordPress ثم فعّلها.
API Base:
https://sauqna.com/wp-json/sooqna/v1/

قبل استخدام أدوار التاجر/المندوب، يجب أن تكون أدوار WordPress/Dokan مضبوطة في الموقع.
