# بناء تطبيق سوقنا على GitHub Actions

هذه النسخة مصممة ليكون **مجلد المشروع نفسه هو جذر مستودع GitHub**.

## مهم جدًا
يجب أن يظهر في الصفحة الرئيسية للمستودع:

```text
pubspec.yaml
lib/
.github/
```

ولا يجب أن يكون المشروع بهذا الشكل:

```text
app/souqna_app/pubspec.yaml
```

## البناء

1. ارفع **محتويات هذا المجلد** إلى جذر مستودع GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build Souqna APK**.
4. اضغط **Run workflow** واختر `main`.
5. بعد نجاح التشغيل افتح الـ run.
6. من قسم **Artifacts** نزّل `souqna-release-apk`.

## لماذا لا يوجد مجلد android داخل المصدر؟

المشروع الحالي يحتوي على كود Flutter فقط، وWorkflow يقوم بإنشاء ملفات Android الرسمية تلقائيًا بواسطة:

```bash
flutter create --platforms=android --project-name souqna_app --org com.alkyanmedia .
```

ثم يتم تشغيل:

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

وبذلك لا نعتمد على مسار Android ناقص أو ملف `build.gradle` غير موجود.

## الناتج

```text
build/app/outputs/flutter-apk/app-release.apk
```

ولا تضع مفاتيح API أو كلمات مرور داخل GitHub repository.
